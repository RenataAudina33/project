package com.e.caribimbel

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import kotlinx.android.synthetic.main.activity_main.*

class MainActivity : AppCompatActivity() {

//    var images:Array<Int> = arrayOf(R.drawable.primagama,R.drawable.tempatprimagama)
//    var adapter:PagerAdapter=SliderAdapter(applicationContext,images)
    var nama = ""
    var email = ""
    var telp = ""
    var alamat = ""
    var deskripsi = ""

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
//
//        viewpager.adapter=adapter
        Primagama.setOnClickListener{navigasiKeDetail()}
    }
    private fun primagamaDetail() {
         nama = "Primagama"
         email = "primagama@gmail.com"
         telp = "0341 414141"
         alamat = "jalan sore-sore"
         deskripsi = "primagama les rame ae"
        navigasiKeDetail()


    }
    private fun navigasiKeDetail() {

        val intent = Intent(this, detail_activity::class.java)
        val bundle = Bundle()
        bundle.putString("nama", nama )
        bundle.putString("email", email)
        bundle.putString("telp", telp)
        bundle.putString("alamat", alamat)
        bundle.putString("deskripsi", deskripsi)

        intent.putExtras(bundle)

        startActivity(intent)

    }
}
