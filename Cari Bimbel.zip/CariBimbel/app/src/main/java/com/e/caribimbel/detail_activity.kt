package com.e.caribimbel


import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import kotlinx.android.synthetic.main.activity_detail.*

class detail_activity: AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_detail)
        ambilData()

    }
    private fun ambilData() {
        val bundle= intent.extras

        val nama = bundle.getString("nama")

        txtNama.text = nama
//
//        txtEmail.text = email
//        txtAlamat.text = alamat
//        txtTelp.text = telp
//        txtDeskripsi.text = deskripsi
    }
}